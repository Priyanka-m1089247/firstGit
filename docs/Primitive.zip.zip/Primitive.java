package Assignments;

public class Primitive {
public static void main (Strings[] args) {
	int a=15;
	byte b=12;
	char c='A';
	double d=4.6;
	short e=23;
	float f= 5.9f;
	long g= 43l;
	boolean h= 4!=34;
	System.out.println("integer data type = "+a);
	System.out.println("byte data type = "+b);
	System.out.println("char data type = "+c);
	System.out.println("double data type = "+d);
	System.out.println("short data type = "+e);
	System.out.println("float data type = "+f);
	System.out.println("long data type = "+g);
	System.out.println("boolean data type = "+h);
}
}
