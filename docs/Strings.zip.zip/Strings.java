package Assignments;

public class Strings {
	
	public static void main(String[] args) {
		String star=new String("java program");
		System.out.println(star.length());
		StringBuffer starbuff=new StringBuffer("java program");
		System.out.println(starbuff.substring(2,5));
	}
	

}
